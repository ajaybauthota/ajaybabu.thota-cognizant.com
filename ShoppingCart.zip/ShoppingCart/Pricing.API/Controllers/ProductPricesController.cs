﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ShoppingCart.DAL;

namespace Pricing.API.Controllers
{
    public class ProductPricesController : ApiController
    {
        private ShoppingCartEntities2 db = new ShoppingCartEntities2();

        // GET: api/ProductPrices
        public IQueryable<ProductPrice> GetProductPrices()
        {
            return db.ProductPrices;
        }

        // GET: api/ProductPrices/5
        [ResponseType(typeof(ProductPrice))]
        public IHttpActionResult GetProductPrice(int id)
        {
            ProductPrice productPrice = db.ProductPrices.Find(id);
            if (productPrice == null)
            {
                return NotFound();
            }

            return Ok(productPrice);
        }

        // PUT: api/ProductPrices/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutProductPrice(int id, ProductPrice productPrice)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != productPrice.ProductPriceId)
            {
                return BadRequest();
            }

            db.Entry(productPrice).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductPriceExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/ProductPrices
        [ResponseType(typeof(ProductPrice))]
        public IHttpActionResult PostProductPrice(ProductPrice productPrice)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.ProductPrices.Add(productPrice);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = productPrice.ProductPriceId }, productPrice);
        }

        // DELETE: api/ProductPrices/5
        [ResponseType(typeof(ProductPrice))]
        public IHttpActionResult DeleteProductPrice(int id)
        {
            ProductPrice productPrice = db.ProductPrices.Find(id);
            if (productPrice == null)
            {
                return NotFound();
            }

            db.ProductPrices.Remove(productPrice);
            db.SaveChanges();

            return Ok(productPrice);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ProductPriceExists(int id)
        {
            return db.ProductPrices.Count(e => e.ProductPriceId == id) > 0;
        }
    }
}