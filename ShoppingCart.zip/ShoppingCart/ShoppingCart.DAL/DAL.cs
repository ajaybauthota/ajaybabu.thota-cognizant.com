﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart.DAL
{
    public static class DAL 
    {
        static ShoppingCartEntities1 DbContext;
        static ShoppingCartEntities2 DbContextPrice;

        static DAL()
        {
            DbContext = new ShoppingCartEntities1();
            DbContextPrice = new ShoppingCartEntities2();
        }

        public static IEnumerable<Product> GetAllProductsByProductTypeId(int id)
        {
            return DbContext.GetAllProductsbyProductType(id);
        }

    }
}
