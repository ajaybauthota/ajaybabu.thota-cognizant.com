﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using System.Web.Http.Results;
using ShoppingCart.Repository;
using Microsoft.Extensions.Logging;
using Infrastructure.Logging;
using ShoppingCart.Models;
using ApplicationCore.Interfaces;

namespace ShoppingCart.Controllers
{
    public class ProductCatalogueController : ApiController
    {  

        private IProductRepository _repository;
        
        public ProductCatalogueController(IProductRepository repository)
        {            
            _repository = repository;
        }

        //[Authorize]
        public IEnumerable<Product> GetProducts()
        {            
            return _repository.GetAll();
        }

        public Product GetProduct(int id)
        {
            Product item = _repository.Get(id);
            if (item == null)
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }
            return item;
        }

        public IEnumerable<Product> GetAllProductsbyProductType(int producttypeid)
        {
            return _repository.GetAll().Where(p => p.ProductTypeId == producttypeid).ToList<Product>();
        }

        public Product PostProduct(Product item)
        {
            item = _repository.Add(item);
            return item;
        }
        //public HttpResponseMessage PostProduct(Product item)
        //{
        //    item = _repository.Add(item);
        //    var response = Request.CreateResponse<Product>(HttpStatusCode.Created, item);

        //    string uri = Url.Link("DefaultApi", new { id = item.Id });
        //    response.Headers.Location = new Uri(uri);
        //    return response;
        //}
        public void PutProduct(int id, Product product)
        {
            product.Id = id;
            if (!_repository.Update(product))
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }
        }
        public void DeleteProduct(int id)
        {
            Product item = _repository.Get(id);
            if (item == null)
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }

            _repository.Remove(id);
        }
    }        
}