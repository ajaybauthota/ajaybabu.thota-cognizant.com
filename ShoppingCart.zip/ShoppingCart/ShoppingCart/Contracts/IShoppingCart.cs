﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ShoppingCart.DAL;

namespace ShoppingCart.Contracts
{
    interface IShoppingCart
    {
    //    decimal GetProductPrice(int ProductId);
    //    dbcontexProducts[] GetProducts(int ProductTypeId);
    //    InsertProduct();
    //    DeleteProduct();
    }
}
