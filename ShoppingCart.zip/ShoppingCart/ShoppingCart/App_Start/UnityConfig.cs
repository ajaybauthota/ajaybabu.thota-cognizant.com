using System.Web.Http;
using ApplicationCore.Interfaces;
using Infrastructure.Logging;
using Microsoft.Extensions.Logging;
using ShoppingCart.Controllers;
using ShoppingCart.Models;
using Unity;
using Unity.Lifetime;
using Unity.WebApi;

namespace ShoppingCart
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            // e.g. container.RegisterType<ITestService, TestService>();
            container.RegisterType<IProductRepository, ProductRepository>(new HierarchicalLifetimeManager());
            //container.RegisterType<ILogger, LoggerAdapter>
            //container.RegisterType<ILogger<ProductCatalogueController>, ILogger<ProductCatalogueController >> (new HierarchicalLifetimeManager());
            //container.RegisterType <typeof(IAppLogger<>, LoggerAdapter<>>(new HierarchicalLifetimeManager());
            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}

