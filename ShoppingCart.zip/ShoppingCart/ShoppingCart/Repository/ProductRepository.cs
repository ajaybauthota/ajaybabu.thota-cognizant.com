﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.ModelBinding;
using ShoppingCart.DAL;
using ShoppingCart.Models;
using ShoppingCart.Repository;

namespace ShoppingCart.Models
{
    public class ProductRepository : IProductRepository, IDisposable
    {
        private List<Product> products = new List<Product>();
        private ShoppingCartEntities1 db = new ShoppingCartEntities1();
      

        public ProductRepository()
        {
            //products =  db.Products;
        }

        public IEnumerable<Product> GetAll()
        {
            EntityMapper<DAL.Product, Models.Product> mapObj = new EntityMapper<DAL.Product, Models.Product>();
             IEnumerable<DAL.Product> prodList = db.Products;
            List<Models.Product> products = new List<Models.Product>();
            foreach (var item in prodList)
            {
                products.Add(mapObj.Translate(item));
            }
            return products;            
        }

        public Product Get(int id)
        {
            EntityMapper<DAL.Product, Models.Product> mapObj = new EntityMapper<DAL.Product, Models.Product>();
            IEnumerable<DAL.Product> prodList = db.Products;
            List<Models.Product> products = new List<Models.Product>();
            foreach (var item in prodList)
            {
                products.Add(mapObj.Translate(item));
            }
            return products.Find(p => p.Id == id);
        }

        public Product Add(Product product)
        {
            if (product == null)
            {
                throw new ArgumentNullException("item");
            }            
            EntityMapper<Models.Product, DAL.Product> mapObj = new EntityMapper<Models.Product, DAL.Product>();
            db.Products.Add(mapObj.Translate(product));
            db.SaveChanges();
            return product;
        }

        public void Remove(int id)
        {
            EntityMapper<DAL.Product, Models.Product> mapObj = new EntityMapper<DAL.Product, Models.Product>();
            IEnumerable<DAL.Product> prodList = db.Products;
            List<Models.Product> products = new List<Models.Product>();
            foreach (var item in prodList)
            {
                products.Add(mapObj.Translate(item));
            }           
            Product product = products.Find(p => p.Id == id);
            if (product == null)
            {
                throw new NotImplementedException();
            }
            EntityMapper<Models.Product, DAL.Product> mapObj1 = new EntityMapper<Models.Product, DAL.Product>();
            db.Products.Remove(mapObj1.Translate(product));
            db.SaveChanges();           
        }       

        public bool Update(Product product)
        {
            if (product == null)
            {
                throw new ArgumentNullException("Product");
            }
            EntityMapper<DAL.Product, Models.Product> mapObj = new EntityMapper<DAL.Product, Models.Product>();
            IEnumerable<DAL.Product> prodList = db.Products;
            List<Models.Product> products = new List<Models.Product>();
            foreach (var item in prodList)
            {
                products.Add(mapObj.Translate(item));
            }
            int index = products.FindIndex(p => p.Id == product.Id);
            if (product == null)
            {
                throw new NotImplementedException();
            }
            EntityMapper<Models.Product, DAL.Product> mapObj1 = new EntityMapper<Models.Product, DAL.Product>();
            db.Products.Remove(mapObj1.Translate(product));
            db.SaveChanges();
            return true;
        }

      
        protected void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (db != null)
                {
                    db.Dispose();
                    db = null;
                }
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }

}