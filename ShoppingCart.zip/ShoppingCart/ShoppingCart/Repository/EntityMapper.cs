﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;
using ShoppingCart.DAL;

namespace ShoppingCart.Repository
{
    public class EntityMapper<TSource, TDestination> where TSource : class where TDestination : class
    {
        public EntityMapper()
        {
            Mapper.CreateMap<Models.Product, Product>().ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name)); ;
            Mapper.CreateMap<Product, Models.Product>().ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.Name)); ; ;
        }
        public TDestination Translate(TSource obj)
        {
            return Mapper.Map<TDestination>(obj);
        }
    }
}